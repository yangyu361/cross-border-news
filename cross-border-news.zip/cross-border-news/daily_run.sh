#!/bin/bash
# 跨境早报 - 每日自动生成脚本
# 用法：将此脚本加入 crontab，每天 7:30 执行

# 1. 激活 Python 环境（按需修改）
# source /path/to/venv/bin/activate

# 2. 进入脚本目录
cd /workspace/cross-border-news

# 3. 生成今日图片
python3 generate.py

# 4. 图片路径
TODAY=$(date +%Y%m%d)
IMG_PATH="/workspace/cross-border-news/cross_border_daily.png"

# 5. 推送到微信（需要企业微信群机器人 Webhook，或调用第三方推送服务）
# 方案 A：企业微信机器人
# WEBHOOK="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY"
# curl -X POST $WEBHOOK -H 'Content-Type: application/json' \
#   -d "{\"msgtype\": \"image\", \"image\": {\"base64\": \"$(base64 -w0 $IMG_PATH)\", \"md5\": \"$(md5sum $IMG_PATH | cut -d' ' -f1)\"}}"

# 方案 B：Server酱 / PushPlus / 飞书机器人（替换为你自己的推送渠道）
# curl -X POST "https://sctapi.ftqq.com/YOUR_KEY.send" \
#   -F "title=跨境早报 $(date +%Y.%m.%d)" \
#   -F "file=@$IMG_PATH"

echo "[$(date)] 跨境早报已生成：$IMG_PATH"
